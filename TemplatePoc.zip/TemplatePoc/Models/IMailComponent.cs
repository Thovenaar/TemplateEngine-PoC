﻿namespace TemplatePoc.Models
{
    public interface IMailComponent
    {
        
    }
}
